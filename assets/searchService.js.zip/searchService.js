.factory('searchService', function($q, $http) {

    return {

      search: function(query) {

        var deferred = $q.defer(),

          // sometimes I have to copy and repaste the string below into the
          // url variable for it to work. Not sure why that is.
          // https://s.yimg.com/aq/autoc?query=aapl&region=CA&lang=en-CA
          url = 'https://s.yimg.com/aq/autoc?query=' + query + '&region=CA&lang=en-CA&callback=JSON_CALLBACK';

        $http.jsonp(url)
          .success(function(data) {
            var jsonData = data.ResultSet.Result;
            deferred.resolve(jsonData);
          })
          .catch(function(error) {
            console.log(error);
          });

        return deferred.promise;
      }
    };
  })
